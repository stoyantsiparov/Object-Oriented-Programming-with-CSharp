﻿namespace RobotService.Models;

public class LaserRadar : Supplement
{
    public LaserRadar()
        : base(20082, 5_000)
    {
    }
}