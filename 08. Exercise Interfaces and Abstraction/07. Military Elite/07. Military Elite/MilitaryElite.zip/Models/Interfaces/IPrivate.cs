﻿namespace MilitaryElite.Models.Interfaces;

public interface IPrivate : ISoldier
{
    public decimal Salary { get; }
}