﻿namespace MilitaryElite.Enums;

public enum Corps
{
    // Енумерациите са константи срещу които стоят числа
    // Клас за енумерация -> зад {Airforces} стои {0}, а зад {Marines} стои {1}
    Airforces,
    Marines
}