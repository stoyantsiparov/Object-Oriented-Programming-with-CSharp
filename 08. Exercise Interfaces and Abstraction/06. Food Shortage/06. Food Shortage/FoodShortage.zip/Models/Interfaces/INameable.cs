﻿namespace BorderControl.Models.Interfaces;

public interface INameable
{
    public string Name { get; }
}