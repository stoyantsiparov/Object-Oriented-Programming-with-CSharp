﻿using BorderControl.Core;
using BorderControl.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();