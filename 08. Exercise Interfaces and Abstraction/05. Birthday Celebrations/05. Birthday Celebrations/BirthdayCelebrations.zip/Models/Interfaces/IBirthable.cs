﻿namespace BorderControl.Models.Interfaces;

public interface IBirthable
{
    public string Birthdate { get; }
}