﻿namespace BorderControl.Core.Interfaces;

public interface IEngine
{
    public void Run();
}