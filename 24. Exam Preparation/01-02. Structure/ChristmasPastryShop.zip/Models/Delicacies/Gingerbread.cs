﻿namespace ChristmasPastryShop.Models.Delicacies
{
    public class Gingerbread : Delicacy
    {
        public Gingerbread(string name)
            : base(name, 4.0)
        {
        }
    }
}