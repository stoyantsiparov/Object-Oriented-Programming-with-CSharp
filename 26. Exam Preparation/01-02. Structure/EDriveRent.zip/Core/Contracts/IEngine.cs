﻿namespace EDriveRent.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
