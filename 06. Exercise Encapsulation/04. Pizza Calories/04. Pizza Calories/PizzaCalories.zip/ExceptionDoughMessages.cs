﻿namespace PizzaCalories;

public class ExceptionDoughMessages
{
    public const string FlourTypeException = "Invalid type of dough.";
    public const string WeightException = "Dough weight should be in the range [1..200].";

}