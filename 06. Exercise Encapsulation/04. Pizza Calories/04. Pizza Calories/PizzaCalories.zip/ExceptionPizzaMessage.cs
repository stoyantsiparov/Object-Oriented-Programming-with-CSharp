﻿namespace PizzaCalories;

public class ExceptionPizzaMessage
{
    public const string NameException = "Pizza name should be between 1 and 15 symbols.";
    public const string ToppingsException = "Number of toppings should be in range [0..10].";
}   