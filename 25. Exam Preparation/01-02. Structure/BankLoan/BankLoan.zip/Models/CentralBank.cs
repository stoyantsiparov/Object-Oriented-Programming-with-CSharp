﻿namespace BankLoan.Models;

public class CentralBank : Bank
{
    public CentralBank(string name)
        : base(name, 50)
    {
    }
}